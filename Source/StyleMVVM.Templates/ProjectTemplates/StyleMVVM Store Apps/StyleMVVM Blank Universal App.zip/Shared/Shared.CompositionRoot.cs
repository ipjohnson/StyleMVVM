﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.Text;
using Windows.UI.Xaml.Controls;
using Grace.DependencyInjection;
using StyleMVVM.Messenger;

namespace $ext_safeprojectname$
{
    public class CompositionRoot : IConfigurationModule
    {
		 public void Configure(IExportRegistrationBlock registrationBlock)
		 {
			 var allTypes = AllTypes();

			 registrationBlock.Export(allTypes).
									 BasedOn<Page>().
									 ByName();

			 registrationBlock.Export(allTypes).
									 ByName().
									 Select(TypesThat.EndWith("ViewModel")).
									 RegisterMessageHandlers();

			 registrationBlock.Export(allTypes).
									 ByInterfaces().
									 Select(TypesThat.EndWith("Service")).
									 RegisterMessageHandlers().
									 AndSingleton();
		 }

	    private List<Type> AllTypes()
	    {
		    return new List<Type>(GetType().GetTypeInfo().Assembly.ExportedTypes);
	    }
    }
}
