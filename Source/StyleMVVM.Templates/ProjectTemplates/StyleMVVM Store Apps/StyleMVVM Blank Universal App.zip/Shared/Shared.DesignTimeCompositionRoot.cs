﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.Text;
using Grace.DependencyInjection;
using StyleMVVM.Messenger;

namespace $ext_safeprojectname$
{
    public class DesignTimeCompositionRoot : IConfigurationModule
    {
	    public void Configure(IExportRegistrationBlock registrationBlock)
	    {
			 var allTypes = AllTypes();

			 registrationBlock.Export(allTypes).
						 ByName().
						 Select(TypesThat.EndWith("ViewModel")).
						 RegisterMessageHandlers();

			 registrationBlock.Export(allTypes).
									 ByInterfaces().
									 Select(TypesThat.EndWith("Service")).
									 RegisterMessageHandlers().
									 AndSingleton();
	    }

		 private List<Type> AllTypes()
		 {
			 return new List<Type>(GetType().GetTypeInfo().Assembly.ExportedTypes);
		 }
    }
}
