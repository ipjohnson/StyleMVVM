﻿using System;
using System.Collections.Generic;
using System.Text;
using StyleMVVM.ViewModel;

namespace $ext_safeprojectname$.ViewModel
{
    public class MainViewModel : PageViewModel
    {
    }
}
