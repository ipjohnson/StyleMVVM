using Grace.DependencyInjection;

namespace $ext_safeprojectname$
{
	public class CompositionRoot : IConfigurationModule
	{
		public void Configure(IExportRegistrationBlock registrationBlock)
		{
			registrationBlock.Export(AllTypes());

			registrationBlock.Export(AllTypes()).
									BasedOn(typeof(Page)).
									ByName();
		}

		private IEnumerable<Type> AllTypes()
		{
			return GetType().GetTypeInfo().Assembly.ExportedTypes;
		}
	}
}